package basics;

public class helloworld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Hello World");

 childclass c = new childclass();
// c.validatemethod();
 System.out.println(c.validatemethod());
 

	}

}
