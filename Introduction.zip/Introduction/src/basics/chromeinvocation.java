
package basics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class chromeinvocation {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
	 System.setProperty("webdriver.chrome.driver", "C://Users//nileshbh//Desktop//Rohit Shetty_Selenium//chromedriver.exe");
     WebDriver cdriver = new ChromeDriver();
     cdriver.get("https://in.bookmyshow.com/");
    
     
     System.out.println(cdriver.getPageSource());
     System.out.println(cdriver.getCurrentUrl());
     System.out.println(cdriver.getTitle());
     cdriver.close();
     
	}

}
