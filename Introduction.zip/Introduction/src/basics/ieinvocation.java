package basics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class ieinvocation {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.ie.driver","C://Users//nileshbh//Desktop//Rohit Shetty_Selenium//IEDriverServer.exe");
		WebDriver idriver = new InternetExplorerDriver();
		idriver.get("https://in.bookmyshow.com/");
		System.out.println(idriver.getPageSource());
	     System.out.println(idriver.getCurrentUrl());
	     System.out.println(idriver.getTitle());
	     idriver.close();
		

	}

}