package basics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class locater1 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.gecko.driver" , "C://Users//nileshbh//Desktop//Rohit Shetty_Selenium//geckodriver.exe" );
        WebDriver driver = new FirefoxDriver();
        driver.get("https://facebook.com");
        driver.findElement(By.name("email")).sendKeys("priya.nil123@gmail.com");
        driver.findElement(By.className("inputtext")).sendKeys("priyarose19");
        driver.findElement(By.id("u_0_2")).click();
	}

}
