package basics;

public class childclass 
{
  public String validatemethod()
  {
	  System.out.println("Method Validated");
	  return("Pass");
  }
	

}


