package Basic2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;



public class program1 {

	@Test
	public void begin()
		{
		System.setProperty("webdriver.chrome.driver", "C://Users//nileshbh//Desktop//Rohit Shetty_Selenium//chromedriver.exe");
		WebDriver dr= new ChromeDriver();
		dr.get("https://mail.cognizant.com/owa/");
		
	 System.out.println("Hello");
		
	}

}
